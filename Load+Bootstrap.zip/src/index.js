import React from "react";
import ReactDOM from "react-dom";
import "jquery";
import "popper.js/dist/umd/popper";
import "bootstrap/dist/js/bootstrap";
import "bootstrap/dist/css/bootstrap.css";

var element = <button class="btn btn-danger">hai</button>;
ReactDOM.render(element, document.getElementById("root"));
